from io import BytesIO
import random
import math
import time
from PIL import Image
from flask import Flask, Response, send_from_directory, jsonify

app = Flask(__name__)

# Serve the HTML page at the root URL
@app.route('/')
def index():
    try:
        with open('index.html', 'r') as f:
            html_content = f.read()
        return html_content
    except Exception as e:
        return f"Error loading index.html: {str(e)}"

# Serve the image stream
@app.route('/video_feed')
def video_feed():
    return Response(get_image(), mimetype='multipart/x-mixed-replace; boundary=frame')

# API endpoint to provide sensor data
@app.route('/api/sensor_data')
def sensor_data():
    # Generate realistic dummy data within narrower ranges to reduce visual jumps
    
    # Heart rate between 60-180 BPM
    bpm = round(random.uniform(60, 180), 1)
    avg_bpm = round(random.uniform(max(60, bpm-15), min(180, bpm+15)), 1)
    
    # Acceleration values (-10 to 10 m/s²) - limiting to smaller range for smoother display
    ax = round(random.uniform(-9.99, 9.99), 2)
    ay = round(random.uniform(-9.99, 9.99), 2)
    az = round(random.uniform(-9.99, 9.99), 2)
    
    # Velocity values (-5 to 5 m/s)
    vx = round(random.uniform(-4.99, 4.99), 2)
    vy = round(random.uniform(-4.99, 4.99), 2)
    vz = round(random.uniform(-4.99, 4.99), 2)
    
    # Temperature (35-40°C for body temp)
    temp = round(random.uniform(35.5, 40.0), 1)
    
    # Stress level (1-10)
    stress = round(random.uniform(1, 9.9), 1)
    
    # IMU values (Yaw, Pitch, Roll in degrees) - limiting to smaller range for display consistency
    yaw = round(random.uniform(-179.9, 179.9), 1)
    pitch = round(random.uniform(-89.9, 89.9), 1)
    roll = round(random.uniform(-179.9, 179.9), 1)
    
    # Position on rink (x: 0-30m, y: 0-60m for hockey rink dimensions)
    pos_x = round(random.uniform(0, 29.9), 1)
    pos_y = round(random.uniform(0, 59.9), 1)
    
    return jsonify({
        'bpm': bpm,
        'avg_bpm': avg_bpm,
        'ax': ax,
        'ay': ay,
        'az': az,
        'vx': vx,
        'vy': vy,
        'vz': vz,
        'temp': f"{temp}°C",
        'stress': stress,
        'yaw': yaw,
        'pitch': pitch,
        'roll': roll,
        'pos_x': pos_x,
        'pos_y': pos_y,
        'timestamp': time.time()
    })

# Serve static files (images, etc.)
@app.route('/<path:filename>')
def static_files(filename):
    return send_from_directory('.', filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False, threaded=True)

def get_image():
    cnt = 0
    while True:
        cnt = cnt + 1
        try:
            if cnt % 2 == 0:
                filename = "streamer.jpg"
            else:
                filename = "rink.jpg"
            with open(filename, "rb") as f:
                image_bytes = f.read()
            image = Image.open(BytesIO(image_bytes))
            img_io = BytesIO()
            image.save(img_io, 'JPEG')
            img_io.seek(0)
            img_bytes = img_io.read()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + img_bytes + b'\r\n')

        except Exception as e:
            print("encountered an exception: ")
            print(e)

            with open("streamer.jpg", "rb") as f:
                image_bytes = f.read()
            image = Image.open(BytesIO(image_bytes))
            img_io = BytesIO()
            image.save(img_io, 'JPEG')
            img_io.seek(0)
            img_bytes = img_io.read()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + img_bytes + b'\r\n')
            continue

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False, threaded=True)
