import asyncio
import websockets
import binascii
from io import BytesIO
from PIL import Image
from flask import Flask, Response
from base64 import b64encode


app = Flask(__name__)

@app.route('/')
def index():
    return Response(get_image(), mimetype='multipart/x-mixed-replace; boundary=frame')


def get_image():
    cnt = 0
    while True:
        cnt = cnt + 1
        try:
            if cnt % 2 == 0:
                filename = "streamer.jpg"
            else:
                filename = "rink.jpg"
            with open(filename, "rb") as f:
                image_bytes = f.read()
            image = Image.open(BytesIO(image_bytes))
            img_io = BytesIO()
            image.save(img_io, 'JPEG')
            img_io.seek(0)
            img_bytes = img_io.read()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + img_bytes + b'\r\n')

        except Exception as e:
            print("encountered an exception: ")
            print(e)

            with open("streamer.jpg", "rb") as f:
                image_bytes = f.read()
            image = Image.open(BytesIO(image_bytes))
            img_io = BytesIO()
            image.save(img_io, 'JPEG')
            img_io.seek(0)
            img_bytes = img_io.read()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + img_bytes + b'\r\n')
            continue

app.run(host='0.0.0.0', debug=False, threaded=True)
